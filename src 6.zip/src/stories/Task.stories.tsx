import React from 'react';
import {Task} from "../Task";
import {ComponentMeta, ComponentStory} from "@storybook/react";
import {TaskType} from "../TodolistWithRedux";

export default {
    title:'TODOLISTS/Task',
    component: Task
} as ComponentMeta<typeof Task>;

const Template: ComponentStory<typeof Task> = (args) => <Task {...args} />

export const TaskIsDoneStory = Template.bind({});

TaskIsDoneStory.args = {
    task: {id:'sss', isDone: true, title: 'JS'},
    todolistId:'ooo'
}