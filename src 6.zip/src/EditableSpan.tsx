import TextField from '@mui/material/TextField/TextField';
import React, {ChangeEvent, memo, useCallback, useState} from 'react';


type EditableSpanPropsType = {
    value: string
    onChange: (newValue: string) => void
}

export const EditableSpan = memo((props: EditableSpanPropsType) => {
    // console.log('Editable Span')
    // debugger

    let [editMode, setEditMode] = useState(false);
    let [title, setTitle] = useState(props.value);


    const activateEditMode = useCallback(() => {
        setEditMode(true);
        setTitle(title);
    },[title]);

    const activateViewMode = useCallback(() => {
        props.onChange(title);
        setEditMode(false);
    }, [props, title])

    const onKeyHandler = useCallback((e: React.KeyboardEvent<HTMLDivElement>) => {
        setEditMode(true);
        if(e.key === 'Enter') {
            props.onChange(title)
            setEditMode(false)
        }
    },[props, title]);

    const changeTitle = useCallback((e: ChangeEvent<HTMLInputElement>) => {
        setTitle(e.currentTarget.value) // change current title in useState
    }, [setTitle]);

    return editMode
        ?    <TextField variant="outlined"
                        value={title} onChange={changeTitle} autoFocus onBlur={activateViewMode} onKeyPress={(e)=>onKeyHandler(e)}/>
        : <span onDoubleClick={activateEditMode}>{title}</span>
})
